        <style>
			.code {
				visibility : hidden;
			}
		</style>
		<?php
            session_start();
            require_once('verbinding.php');
			include('phpqrcode/qrlib.php');
            if(!isset($_SESSION['username']) & empty($_SESSION['username'])){
            header('location:index.php'); //redirect naar index.php als je niet ingelogd bent.
            }
            $username = $_SESSION['username'];
            $user_id     = $_SESSION['user_id'];
			$code_one = rand(1001, 9001);
			$code_two = rand(1001, 9001);
			$code_three = rand(1001, 9001);
			QRcode::png($code_one, "new.png", "M", "10", "10");
			QRcode::png($code_two, "new2.png", "M", "10", "10");
			QRcode::png($code_three, "new3.png", "M", "10", "10");
			
        ?>
        <!DOCTYPE html>
          <?php
		if(isset($_POST["submit"])){
			echo "clicked";
			$code = $_POST['code'];
			$touser = $_REQUEST['user'];
			$code_one = htmlentities(mysqli_escape_string($conn, $_POST['code_one']));
			$code_two = $_POST['code_two'];
			$code_three = $_POST['code_three'];
			if($code == $code_one){
				echo "Working Code_one <br>";
				mysqli_query($conn, "UPDATE users SET balance = balance - 10 WHERE id = '$user_id'");
				mysqli_query($conn, "UPDATE users SET balance = balance + 10 WHERE id = $touser");
			}
			elseif($code == $code_two){
				mysqli_query($conn, "UPDATE users SET balance = balance - 30 WHERE id = '$user_id'");
				mysqli_query($conn, "UPDATE users SET balance = balance + 30 WHERE id = $touser");
			}
			elseif($code == $code_three){
				mysqli_query($conn, "UPDATE users SET balance = balance - 50 WHERE id = '$user_id'");
				mysqli_query($conn, "UPDATE users SET balance = balance + 50 WHERE id = $touser");
			}
		}
          ?>
          <!doctype html>
          <html lang="en">
            <head>
              <!-- Required meta tags -->
              <meta charset="utf-8">
              <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
              <!-- Bootstrap CSS -->
              <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
              <title>Kameleon</title>
              <style>.carousel-inner > .item > img { width:100%; height:570px; } </style>
               <link rel="stylesheet" type="text/css" href="style.css">
            </head>
          <body>
          <nav class="navbar navbar-dark bg-dark">
          <!-- Navbar content -->
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
          <div class="collapse navbar-collapse" id="navbarText">
            <ul class="navbar-nav mr-auto">
              <li class="nav-item">
                <a class="nav-link" href="register.php">Register</a>
              </li>
              <li class="nav-item active">
                <a class="nav-link" href="login.php">My Account <span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">Customer Service</a>
              </li>
            </ul>
          </div>
          <a class="navbar-brand" href="index.php">Kameleon</a>
        </nav><br><br>
          <h1 class="display-3">Members area </h1>
          <br>
            <?php
                $sql = "SELECT * FROM users WHERE id='$user_id'";
                $result = mysqli_query($conn, $sql);

                if($row = mysqli_fetch_array($result))
                {
                    $username = $row["username"];
                    $balance = $row['balance'];
                    if ($balance < 0) {
                      echo "Okay";
                    }
                    $sql = "SELECT balance FROM balanceview WHERE user_id=$user_id";
                    $result = mysqli_query($conn, $sql);

                    $row = mysqli_fetch_array($result);
                    echo "Hallo $username, jouw balans is: $balance euro";
                  }
            ?>
            <br><br>
              <form action='' method='POST' enctype="multipart/form-data">
                      
					 <div class="test">
					 <input type="text" name="user" />
                     <input type='text' name='code_one' value=<?php echo $code_one?> class="code"/>
					<input type='text' name='code_two' value=<?php echo $code_two?> class="code" />
					<input type='text' name='code_three' value=<?php echo $code_three?> class="code" /><br>
                    </div>
					<label>Code</label> <input type='text' name='code' value="" /><br>
                      <input type='submit' name='submit' class='knop' value='send'><br>
                    </div>
              </form>
              <br>
			  <p>Scan to send 10$</p>
			  <img src="new.png" />
			   <p>Scan to send 30$</p>
			  <img src="new2.png" />
			   <p>Scan to send 50$</p>
			  <img src="new3.png" />
              <a href='logout.php'> Logout </a>
            <!-- jQuery first, then Tether, then Bootstrap JS. -->
            <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
            <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
          </body>
          <footer>
            <nav class="navbar fixed-bottom navbar-dark bg-dark">
          <a class="navbar-brand" href="register.php">Register</a>
          <a class="navbar-brand" href="login.php">My Account</a>
          <a class="navbar-brand" href="about.php">About Us</a>
        </nav>
          </footer>
        </html>
