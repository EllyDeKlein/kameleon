<?php
$secret = "6Ld9AmwUAAAAAIadINTtMeBs8N4rcPPyOr-Z3f21";
?>
