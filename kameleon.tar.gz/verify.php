<?php

$nr = Rand(1,9001);

?>
